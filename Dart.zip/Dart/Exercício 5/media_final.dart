// Exercício 5: Usar código desenvolvido para 
// calcular a média e adicionar uma estrutura
// if-else, nela deve exibir na tela a mensagem
// "Aprovado" se o aluno estiver com a média
// maior ou igual a 7, senão exibir a mensagem
// "Reprovado" se o aluno não estiver com a média
// menor ou igual a 6

void main(){
   // Declaração das variáveis
   double nota1 = 10;
   double nota2 = 10;
   
   // Cálculo da média
   double media = (nota1 + nota2) / 2;
      
   // Verifica se a média for maior que 7
   if(media >= 7){
      print("Aprovado!");
   } else {
      print("Reprovado!");
   }
}
 