//Exercício 1: Criar um algoritmo que faz
// a média de duas notas de alunos e mostra
// o resultado final.

void main(){
     
   // Declaração das variáveis
   double nota1 = 10;
   double nota2 = 10;
   
   // Cálculo da média
   double media = (nota1 + nota2) / 2;

   // Exibindo na tela a média
   print('A média do aluno é: $media');

}