// Exercício 2: fazer um algoritmo que calcula
// quanto você irá receber do seu décimo terceiro

void main() {
  
  // Criação das variáveis
  double salario = 710;
  double tempo_trabalhado = 8;

  double decimo_terceiro;
  
  // Cálculo decimo
  decimo_terceiro = (salario / 12) * tempo_trabalhado;

  // exibindo na tela
  print('O valor do seu décimo terceiro é: $decimo_terceiro');
  
}