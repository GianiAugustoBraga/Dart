// Exercício 3: Algoritmo que faz o saque de um 
// valor de uma conta bancária.

void main(){
  // Criação das variáveis
  double saldo = 430;
  double saque = 100;

  double valor_total;

  // Cálculo do valor final da conta
  valor_total = saldo - saque;

  // Exibe na tela o saldo final
  print('Seu saldo é de: $valor_total');
}