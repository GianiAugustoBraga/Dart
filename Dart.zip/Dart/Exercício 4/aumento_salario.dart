// Exercício 4: Escrever um algoritmo para 
// ler o salário mensal de um funcionário e o 
// percentual de reajuste.

void main (){
  // Criação das variáveis 
  double salario = 710;
  double percentual = 25;

  double novo_salario;
  double aumento;

  aumento = (salario * percentual) /100;
  novo_salario = salario + aumento;

  print('Seu novo salário é: $novo_salario');

}